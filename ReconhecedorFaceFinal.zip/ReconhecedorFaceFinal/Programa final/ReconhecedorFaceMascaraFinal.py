import tensorflow.keras

from tensorflow.keras.models import model_from_json
import numpy as np
from picamera import PiCamera
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications import resnet50
print("Carregndo base Convolucional Resnet-50")
baseConvolucional = resnet50.ResNet50(
    weights='imagenet',
    include_top=False, 
    input_shape=(150, 150, 3))
print("Carregando Modelo ")

# Carregando modelo
json_file = open('modelo12de50Ejson.json', 'r')
loaded_model_json = json_file.read()
json_file.close()
modelo = model_from_json(loaded_model_json)
# Carregando pesos
modelo.load_weights("modelo12de50EH.h5")

camera = PiCamera()

camera.resolution = (150,150)
camera.start_preview()
while True:
    camera.capture("/home/pi/Desktop/imagem.png")
    imagem = image.load_img("/home/pi/Desktop/imagem.png", target_size = (150,150))
    imagem = image.img_to_array(imagem)
    imagem = np.expand_dims(imagem, axis=0)
    
    caracteristicasImagem = baseConvolucional.predict(imagem)
    caracteristicasImagem = np.reshape(caracteristicasImagem, (1,51200)) #51200 é o número de neuronios de entrada da rede neural
    
    saidaNeural = modelo.predict(caracteristicasImagem)
    print(saidaNeural)
    
    if saidaNeural < 0.5:
        print ("Com Máscara")
    else:
        print ("Sem Máscara")
