

# -*- coding: utf-8 -*-


import keras
from keras import layers
from keras import models
from keras import optimizers
from keras import regularizers
import matplotlib.pyplot as plt
from keras.preprocessing.image import ImageDataGenerator
from keras.applications import resnet50
import numpy as np
print ("0")
baseConvolucional = resnet50.ResNet50(
    weights='imagenet',
    include_top=False, 
    input_shape=(150, 150, 3))
reescalonando = ImageDataGenerator(rescale=1./255)
tamanhoLote = 10

caracteristicasTreino =  np.zeros(shape=(1000, 5, 5, 2048))
rotulosTreino = np.zeros([1000])
gerador = reescalonando.flow_from_directory(
  'C:/BD/ReconhecimentoMascara3/Treino',
  target_size=(150, 150),
  batch_size=tamanhoLote,
  class_mode='binary')
i = 0

for quantLoteEntrada, quantLoteRotulos in gerador:    
    caracteristicasLote = baseConvolucional.predict(quantLoteEntrada)
    caracteristicasTreino[i * tamanhoLote : (i + 1) * 
                          tamanhoLote] = caracteristicasLote
    rotulosTreino[i * tamanhoLote : (i + 1) * tamanhoLote] = quantLoteRotulos
    i += 1
    if i * tamanhoLote >= 1000:   
        break

caracteristicasTeste =  np.zeros(shape=(200, 5, 5, 2048))
rotulosTeste = np.zeros([200])
gerador = reescalonando.flow_from_directory(
  'C:/BD/ReconhecimentoMascara3/Teste',
  target_size=(150, 150),
  batch_size=tamanhoLote,
  class_mode='binary')
i = 0
for quantLoteEntrada, quantLoteRotulos in gerador:
    caracteristicasLote = baseConvolucional.predict(quantLoteEntrada)
    caracteristicasTeste[i * tamanhoLote : (i + 1) * 
                          tamanhoLote] = caracteristicasLote
    rotulosTeste[i * tamanhoLote : (i + 1) * tamanhoLote] = quantLoteRotulos
    i += 1
    if i * tamanhoLote >= 200:
      break


caracteristicasTreino = np.reshape(
    caracteristicasTreino, (1000, 51200))

caracteristicasTeste = np.reshape(
    caracteristicasTeste, (200, 51200))

modelo = models.Sequential()
modelo.add(layers.Dense(128, kernel_regularizer=regularizers.l1_l2(
    l1=0.001, l2=0.001), activation='relu', input_dim=5 * 5 * 2048))
modelo.add(layers.Dropout(0.5))
modelo.add(layers.Dense(64, kernel_regularizer=regularizers.l1_l2(
    l1=0.001, l2=0.001), activation='relu'))
modelo.add(layers.Dropout(0.5))
modelo.add(layers.Dense(32, activation='relu'))
modelo.add(layers.Dropout(0.5))
modelo.add(layers.Dense(1, activation='sigmoid'))
modelo.compile(optimizer=optimizers.RMSprop(lr=2e-5),
  loss='binary_crossentropy',
  metrics=['acc'])

historico = modelo.fit(caracteristicasTreino, rotulosTreino,
  epochs=50,
  batch_size=tamanhoLote
  )

acc = historico.history['acc']
loss = historico.history['loss']
epochs = range(1, len(acc) + 1)
plt.plot(epochs, acc, 'bo', label='Training acc')
plt.title('Exatidão do treino')
plt.legend()
plt.figure()
plt.plot(epochs, loss, 'bo', label='Training loss')
plt.title('Perda do treino')
plt.legend()
plt.show()

test_loss, test_acc = modelo.evaluate(caracteristicasTeste, rotulosTeste)
print ("Exatidão da rede neural:", test_acc)

model_json = modelo.to_json()
with open("modelo12de50Ejson.json", "w") as json_file:
    json_file.write(model_json)
# Serializando pesos para HDF5
modelo.save_weights("modelo12de50EH.h5")
print("Modelo Salvo")
# serialize model to YAML
model_yaml = modelo.to_yaml()
with open("modelo12de50Eyaml.yaml", "w") as yaml_file:
    yaml_file.write(model_yaml)
